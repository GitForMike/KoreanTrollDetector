# char-level-cnn-tf
Implementation of Character-level Convolutional Networks for Text Classification in TensorFlow.

Based on ideas from Denny Britz's code which can be found here: https://github.com/dennybritz/cnn-text-classification-tf

MIT License
